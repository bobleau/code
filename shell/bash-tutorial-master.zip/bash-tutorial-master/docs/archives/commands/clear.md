# clear

`clear`命令用来清除当前屏幕的显示，运行后会只留下一个提示符。

```bash
$ clear
```
