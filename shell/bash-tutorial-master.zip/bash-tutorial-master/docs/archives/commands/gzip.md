# gzip

`gzip`命令用于压缩文件。
