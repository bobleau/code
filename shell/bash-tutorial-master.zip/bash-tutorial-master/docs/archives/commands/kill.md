# kill

`kill`命令用户终止指定进程。

```bash
$ kill PID
```
