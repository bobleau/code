# alias

`alias`命令用于设置别名。通常用于在 Bash 设置文件中，设置别名。

```bash
alias dockerlogin='ssh www-data@adnan.local -p2222'
```
