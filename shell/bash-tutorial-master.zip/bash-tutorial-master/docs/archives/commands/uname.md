# uname

`uname`命令用来显示内核信息。

```bash
$ uname -a
```
