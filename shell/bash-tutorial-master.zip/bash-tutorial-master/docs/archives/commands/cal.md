# cal

`cal`命令显示本月的日历。

```bash
$ cal
```
