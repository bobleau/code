# whereis

`whereis`用来显示某个命令的位置。如果有多个程序符合条件，会全部列出。

```bash
$ whereis node
/usr/bin/node /usr/sbin/node
```

