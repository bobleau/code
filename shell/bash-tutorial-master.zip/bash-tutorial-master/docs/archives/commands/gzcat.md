# gzcat

`gzcat`命令用于查看一个`gz`文件，但并不实际解压它。

```bash
$ gzcat filename
```

