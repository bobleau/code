# lpr

`lpr`命令用于打印文件。

```bash
lpr filename
```

