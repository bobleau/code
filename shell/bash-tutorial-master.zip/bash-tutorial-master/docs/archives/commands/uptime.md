# uptime

`uptime`命令显示本次开机运行的时间。
