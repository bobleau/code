本教程介绍 Linux 命令行 Bash 的基本用法和脚本编程。
