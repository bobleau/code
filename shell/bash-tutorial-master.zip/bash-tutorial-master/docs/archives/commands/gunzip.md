# gunzip

`gunzip`命令用于解压`gzip`命令压缩的文件。
