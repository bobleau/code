# killall

`killall`命令终止给定名字的一系列相关进程。

```bash
$ killall processname
```
