# last

`last`命令显示用户登录系统的记录。

```bash
$ last
```

`last`命令后面加上用户名，会显示该用户上次登录的信息。

```bash
$ last yourUsername
```

