# date

`date`命令显示当前的日期和时间。

```bash
$ date
```
