# which

`which`命令根据`PATH`环境变量指定的顺序，返回最早发现某个命令的位置。即不指定路径时，实际执行的命令的完整路径。

```bash
$ which node
/usr/bin/node
```
