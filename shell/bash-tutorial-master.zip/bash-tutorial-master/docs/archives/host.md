# 主机管理

## hostname命令

`hostname`命令返回当前服务器的主机名。

```bash
$ hostname
```
